NOTE: Since I created a folder structure, I am attaching the complete framework as a zip file which need to be extracted to "C:\Users\<userName>\source\repos"

1) I have used below tools & technologies for this framework. 
visual studio 2019
Selenium - v3.141
ChromeDriver - v77
Specflow - v3.0
Nunit - 3.11
Gherkin - v6.0

2) Please note I have given the path to chrome driver  as 
driver = new ChromeDriver(@"C:\Users\Guna\source\repos\AudenTest\CommonUtilities\Tools\WebDriver_Chrome");
So, "C:\Users\Guna" need to be replaced with your details to launch the browser successfully. 

3) I have attached few screenshots of folder structure, Test results, and plugsin I installed. Please refer to them.