﻿using System;
using AudenTest.CommonUtilities;
using AudenTest.PageObjects;
using NUnit.Framework;
using TechTalk.SpecFlow;


namespace AudenTest
{
    [Binding]
    public class LoanCalculatorTestsSteps
    {

        [BeforeScenario]
        public void SetUp()
        {
            LoansCalculatorPage.OpenBrowser();
        }

        [AfterScenario]
        public void TearDown()
        {
            LoansCalculatorPage.CloseBrowser();
        }

        [Given(@"User on Auden loans page")]
        public void GivenUserOnAudenLoansPage()
        {
            LoansCalculatorPage.NavigateToAudenLoansPage();
            LoansCalculatorPage.AcceptCookies();
        }
        
        [When(@"User select the desired loan amount")]
        public void WhenUserSelectTheDesiredLoanAmount()
        {
            LoansCalculatorPage.SelectLoanAmount();
        }
        
        [When(@"User select the desired number of installments")]
        public void WhenUserSelectTheDesiredNumberOfInstallments()
        {
            LoansCalculatorPage.SelectMonthlyInstallment();
        }
        
        [When(@"User select day of repayment as weekend")]
        public void WhenUserSelectDayOfRepaymentAsWeekend()
        {
            LoansCalculatorPage.SelectRepaymentDay();
        }
        
        [Then(@"User should see First Repayment Date lessthan dayOFRepayment")]
        public void ThenUserShouldSeeFirstRepaymentDateLessthanDayOFRepayment()
        {
            Assert.True(FutureDate.GetNextSundayDate()  < LoansCalculatorPage.GetRepaymentDate(), "The Repayments date is not prior to Selected date");
        }
        
        [Then(@"First repayment dat should not be weekend")]
        public void ThenFirstRepaymentDatShouldNotBeWeekend()
        {
            Assert.True(condition: (LoansCalculatorPage.GetDayFromRepaymentDate()) != LoanPageConstants.Weekend.Saturday.ToString() 
                                   && (LoansCalculatorPage.GetDayFromRepaymentDate()) != LoanPageConstants.Weekend.Sunday.ToString(), "The Repayments day is weekend day");

        }

        [When("User select the Minimum loan amount on slider")]
        public void userSelectTheMinimumLoanAmountOnSlider()
        {
            LoansCalculatorPage.SelectMinimumLoanAmount();
        }

        [Then(@"User should see Loan amount as ""(.*)")]
        public void userShouldSeeLoanAmountAs(String LoanAmount)
        {
            Assert.True(LoanAmount.Contains(LoansCalculatorPage.GetLoanAmount()), "Loan amount at header is incorrect");
        }

        [When("User select the Maximum loan amount on slider")]
        public void userSelectTheMaximumLoanAmountOnSlider()
        {
            LoansCalculatorPage.SelectMaximumLoanAmount();
        }

        [When("User move slider to middle of the bar")]
        public void userMoveSliderToMiddleOfTheBar()
        {
            LoansCalculatorPage.MoveSliderToMiddle();
        }
    }
}
