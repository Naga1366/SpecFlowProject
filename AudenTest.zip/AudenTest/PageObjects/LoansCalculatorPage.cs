﻿using System;
using System.Threading;
using AudenTest.CommonUtilities;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Internal;

namespace AudenTest.PageObjects
{
    public class LoansCalculatorPage
    {
        public static IWebDriver driver;
        
        private static Actions actions => new Actions(driver);
        private static readonly int nextSundayDate = FutureDate.GetNextSundayDate();

        private static IWebElement LoanAmountAtHeader => driver.FindElement(By.XPath("//div[@class='loan-amount__header__amount']/span"));
        private static IWebElement ConfirmedRepaymentDate => driver.FindElement(By.XPath("//span[@class='loan-schedule__tab__panel__detail__tag']/label[1]"));
        private static IWebElement ExpandCalender => driver.FindElement(By.XPath("//span[contains(@class,'button__icon')]"));
        private static IWebElement CookieConsentButton => driver.FindElement(By.Id("cookie-consent"));
        private static IWebElement LoanAmountSlider =>driver.FindElement(By.XPath("//div[contains(@class,'loan-amount__range-slider')]//input"));
        private static IWebElement MonthlyInstallmentSlider => driver.FindElement(By.XPath("//div[contains(@class,'loan-schedule__tab__range-slider')]//input"));
        private static IWebElement RepaymentDate => driver.FindElement(By.XPath( "//button[@value='" + nextSundayDate + "']" ));
        
        public static void NavigateToAudenLoansPage()
        {
            driver.Navigate().GoToUrl("https://www.auden.co.uk/credit/ShortTermLoan");
        }

        public static void OpenBrowser()
        {
            driver = new ChromeDriver(@"C:\Users\Guna\source\repos\AudenTest\CommonUtilities\Tools\WebDriver_Chrome");
            driver.Manage().Window.Maximize();
        }

        public static void CloseBrowser()
        {
            driver.Close();
        }

        public static void AcceptCookies()
        {
            Thread.Sleep(5000);
            CookieConsentButton.Click();
        }

        public static void SelectLoanAmount()
        {
            actions.ClickAndHold(LoanAmountSlider).MoveByOffset((GetWidthOfSlider() / 2), 0).Release().Build().Perform();
        }

        public static int GetWidthOfSlider()
        {
            int xCoordinates = LoanAmountSlider.Size.Width;
            return xCoordinates;
        }

        public static void SelectMonthlyInstallment()
        {
            int installmentSliderXCoordinates = MonthlyInstallmentSlider.Size.Width;
            Actions installmentSliderActions = new Actions(driver);
            installmentSliderActions.ClickAndHold(MonthlyInstallmentSlider).MoveByOffset(installmentSliderXCoordinates / 2, 0).Release().Build().Perform();
        }

        public static void SelectRepaymentDay()
        {
            Thread.Sleep(3000);
            ExpandCalender.Click();
            
            Thread.Sleep(3000);
            RepaymentDate.Click();
        }

        public static int GetRepaymentDate()
        {
            driver.WaitForCondition(condition => ConfirmedRepaymentDate.Displayed, CommonUtilities.LoanPageConstants.RenderTimeShort);
            return FutureDate.ExtractDateOnlyFromDate(ConfirmedRepaymentDate.Text);
        }

        public static string GetDayFromRepaymentDate()
        {
            driver.WaitForCondition(condition => ConfirmedRepaymentDate.Displayed, CommonUtilities.LoanPageConstants.RenderTimeShort);
            return FutureDate.ExtractDayFromDate(ConfirmedRepaymentDate.Text);
        }

        public static void SelectMinimumLoanAmount()
        {
            actions.ClickAndHold(LoanAmountSlider).MoveByOffset(-(GetWidthOfSlider() / 2), 0).Release().Build().Perform();
        }

        public static void SelectMaximumLoanAmount()
        {
            actions.ClickAndHold(LoanAmountSlider).MoveByOffset((GetWidthOfSlider() / 2), 0).Release().Build().Perform();
        }

        public static string GetLoanAmount()
        {
            return LoanAmountAtHeader.Text;
        }

        public static void MoveSliderToMiddle()
        {
            actions.ClickAndHold(LoanAmountSlider).MoveByOffset(0, 0).Release().Build().Perform();
        }
    }
}