﻿
using System;
using System.Diagnostics;

namespace AudenTest.CommonUtilities
{
    public static class WebDriverExtensions
    {
        public static void WaitForCondition<T>(this T obj, Func<T, bool> condition, int timeout)
        {
            Func<T, bool> execute = (arg) =>
            {
                try
                {
                    return condition(arg);
                }
                catch
                {
                    return false;
                }
            };

            var stopWatch = Stopwatch.StartNew();
            while (stopWatch.ElapsedMilliseconds < timeout)
            {
                if (execute(obj))
                {
                    break;
                }
            }
        }
    }
}
