﻿using System;


namespace AudenTest.CommonUtilities
{
    public class FutureDate
    {
        public static int GetNextSundayDate()
        {
            DateTime date = DateTime.Today;
            DateTime nextWeekendDate = date.AddDays(7- (int)date.DayOfWeek);
            return nextWeekendDate.Day;
        }

        public static int ExtractDateOnlyFromDate(string RepaymentDateFull)
        {
            String[] arrayOfRepaymentDate = RepaymentDateFull.Split(' ');
            return Int32.Parse(arrayOfRepaymentDate[1]);
        }

        public static string ExtractDayFromDate(string RepaymentDateFull)
        {
            String[] arrayOfRepaymentDate = RepaymentDateFull.Split(' ');
            return arrayOfRepaymentDate[0];
        }
    }
}
