﻿

namespace AudenTest.CommonUtilities
{
    public class LoanPageConstants
    {
        public enum Weekend
        {
            Saturday,
            Sunday
        }

        public const int RenderTimeShort = 5000;
    }
}
